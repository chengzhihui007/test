PL/HQL Tool
===========

Procedural SQL extension for Apache Hive, Impala and other SQL-on-Hadoop implementations.
